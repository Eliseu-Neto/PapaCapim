import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

export default function PostScreen() {
  const [postContent, setPostContent] = useState('');

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Escreva sua postagem..."
        value={postContent}
        onChangeText={setPostContent}
        style={styles.input}
        multiline
      />
      <Button title="Postar" onPress={() => alert('Postado!')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  input: { height: 100, borderColor: 'gray', borderWidth: 1, marginBottom: 10, paddingHorizontal: 10, textAlignVertical: 'top' },
});
