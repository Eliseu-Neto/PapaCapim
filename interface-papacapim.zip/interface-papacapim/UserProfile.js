import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function UserProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nome do Usuário</Text>
      <Text>Email: usuario@exemplo.com</Text>
      <Text>Postagens: 123</Text>
      <Button title="Seguir" onPress={() => alert('Seguindo!')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  title: { fontSize: 24, marginBottom: 20 },
});
