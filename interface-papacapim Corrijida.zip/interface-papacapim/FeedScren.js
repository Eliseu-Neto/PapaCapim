import React from 'react';
import { View, Text, Button, StyleSheet, FlatList } from 'react-native';

const posts = [
  { id: '1', user: 'User1', content: 'Primeiro post!' },
  { id: '2', user: 'User2', content: 'Olá, mundo!' },
  { id: '3', user: 'User3', content: 'React Native é incrível!' },
];

export default function FeedScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.post}>
            <Text style={styles.user}>{item.user}</Text>
            <Text>{item.content}</Text>
          </View>
        )}
      />
      <Button title="Nova Postagem" onPress={() => navigation.navigate('Post')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10 },
  post: { marginBottom: 15, padding: 10, backgroundColor: '#f9f9f9', borderRadius: 5 },
  user: { fontWeight: 'bold', marginBottom: 5 },
});
